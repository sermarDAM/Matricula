package com.example.matricula.Asignaturas;

public class ListaAsignatura {

    public int id;
    public String nombre;
    public int numAlumnos;

}
