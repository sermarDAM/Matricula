package com.example.matricula.Asignaturas;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;


import com.example.matricula.Datas.Asignatura.Asignatura;
import com.example.matricula.R;

public class Asignaturas extends AppCompatActivity implements AsignaturaDialog.OnSimpleDialogListener {


    private AsigViewModel Asigvm;
    private RecyclerView rvList;
    private AdapterAs AsigAdapter;
    private String icon_imagen;
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.asignaturas);

        getSupportActionBar().setTitle("Asignaturas");

        ViewModelProvider.AndroidViewModelFactory factory =
                ViewModelProvider.AndroidViewModelFactory.getInstance(getApplication());

        Asigvm = new ViewModelProvider(this, factory)
                .get(AsigViewModel.class);

        setupList();
        setupFab();


    }

    private void setupList() {
        rvList = findViewById(R.id.listaAsignaturas);
        AsigAdapter = new AdapterAs();
        rvList.setAdapter(AsigAdapter);

        AsigAdapter.setItemListener(new AdapterAs.ItemListener() {


            @Override
            public void onEditIconClicked(ListaAsignatura Asignatura) {

            }

            @Override
            public void onDeleteIconClicked(ListaAsignatura Asignatura) {

                int id = Asignatura.id;
                Asigvm.eliminarAsignatura(Asignatura);
                Toast.makeText(getApplication(), "Eliminado " + id, Toast.LENGTH_SHORT).show();

            }
        });

        Asigvm.ListarTodoAsi().observe(this, AsigAdapter::setItems);


    }

    private void setupFab() {

        findViewById(R.id.floatAsignaturas)
                .setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        icon_imagen = "añadir";
                        Asignatura_dialog();
                    }
                });
    }

    private void Asignatura_dialog() {

        new AsignaturaDialog().show(getSupportFragmentManager(), "DialogAsignatura"); //instanciamos el dialogo

    }

    @Override
    public void onPossitiveButtonClick(String nombreAsig, int id, int cantAsign) {


        if (icon_imagen.equals("añadir")) {

            Asignatura a = new Asignatura(nombreAsig);
            Asigvm.insert(a);
            Toast.makeText(this, "Añadido " + nombreAsig, Toast.LENGTH_SHORT).show();

        }

        }
    }

