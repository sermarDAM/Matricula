package com.example.matricula.Alumnos;

public class dniAlumno {

    public String DNI;

    public dniAlumno(String DNI){
        this.DNI = DNI;
    }
}
