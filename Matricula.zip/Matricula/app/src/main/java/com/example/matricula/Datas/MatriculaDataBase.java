package com.example.matricula.Datas;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

import com.example.matricula.Datas.Alumno.Alumno;
import com.example.matricula.Datas.Alumno.AlumnoDAO;
import com.example.matricula.Datas.Asignatura.Asignatura;
import com.example.matricula.Datas.Asignatura.AsignaturaDAO;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Database(entities = {Alumno.class,
                    Asignatura.class}, version = 2, exportSchema = false)
public abstract  class MatriculaDataBase extends RoomDatabase {

    // Exposición de DAOs
    public abstract AlumnoDAO AlumnoDao();

    public abstract AsignaturaDAO AsignaturaDao();

    private static final String DATABASE_NAME = "AlumnosAsignaturas-bd";

    private static MatriculaDataBase INSTANCE;

    private static final int THREADS = 4;

    public static final ExecutorService mdbExecutor = Executors.newFixedThreadPool(THREADS);

    public static MatriculaDataBase getInstance(final Context context) {

        if (INSTANCE == null) {
            synchronized (MatriculaDataBase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(
                            context.getApplicationContext(), MatriculaDataBase.class, DATABASE_NAME).addCallback(nuevoCallback).build();
                }
            }
        }
        return INSTANCE;
    }
    private static final RoomDatabase.Callback nuevoCallback = new Callback() {
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);

            mdbExecutor.execute(() -> {

                AlumnoDAO alumnoDao = INSTANCE.AlumnoDao();

                AsignaturaDAO asignaturaDao = INSTANCE.AsignaturaDao();

                Alumno a1 = new Alumno("7346127", "Sergio", "Martinez");

                alumnoDao.insert(a1);

                Asignatura asig1 = new Asignatura("Bases de Datos");
                Asignatura asig2 = new Asignatura("Programación");
                Asignatura asig3 = new Asignatura("Android");

                asignaturaDao.insert(asig1);
                asignaturaDao.insert(asig2);
                asignaturaDao.insert(asig3);

            });
        }
    };
}
