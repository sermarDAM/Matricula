package com.example.matricula.Asignaturas;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.matricula.R;

import java.util.List;

public class AdapterAs extends RecyclerView.Adapter<AdapterAs.AsignaturaViewHolder> {

    private List<ListaAsignatura> Asignaturas;
    private ItemListener itemListen;

    @NonNull
    @Override
    public AsignaturaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new AsignaturaViewHolder(
                LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.itemslist_asignatura, parent, false)
        );
    }

    @Override
    public void onBindViewHolder(@NonNull AsignaturaViewHolder holder, int position) {
        ListaAsignatura item = Asignaturas.get(position);
        holder.bind(item);
    }

    @Override
    public int getItemCount() {
        return Asignaturas == null ? 0 : Asignaturas.size();
    }

    public void setItems(List<ListaAsignatura> items) {
        Asignaturas = items;
        notifyDataSetChanged();
    }

    public void setItemListener(ItemListener listener) {
        itemListen = listener;
    }

    interface ItemListener {
        void onEditIconClicked(ListaAsignatura Asignatura);
        void onDeleteIconClicked(ListaAsignatura Asignatura);
    }

    public class AsignaturaViewHolder extends RecyclerView.ViewHolder {

        private TextView nombreAsigntxt,cantAlumntxt,idtxt;
        private ImageView borAsig, actAsig;

        public AsignaturaViewHolder(@NonNull View itemView) {
            super(itemView);
            nombreAsigntxt = itemView.findViewById(R.id.newAsigNombre);
            idtxt = itemView.findViewById(R.id.idAsig);
            cantAlumntxt = itemView.findViewById(R.id.newNumAlum);
            actAsig = itemView.findViewById(R.id.actAsig);
            borAsig = itemView.findViewById(R.id.BorAsig);


            actAsig.setOnClickListener(this::manageEvents);
            borAsig.setOnClickListener(this::manageEvents);

            itemView.setOnClickListener(this::manageEvents);


        }

        private void manageEvents(View view) {
            if (itemListen != null) {
                ListaAsignatura clickedItem = Asignaturas.get(getAdapterPosition());

                if (view.getId() == R.id.actAsig) {
                    itemListen.onEditIconClicked(clickedItem);
                }
                if (view.getId() == R.id.BorAsig) {
                    itemListen.onDeleteIconClicked(clickedItem);
                    return;
                }
            }
        }


        public void bind(ListaAsignatura item) {

            nombreAsigntxt.setText(item.nombre);
            idtxt.setText(String.valueOf(item.id));
            cantAlumntxt.setText(String.valueOf(item.numAlumnos) + " alumnos");
        }
    }
}
