package com.example.matricula.Datas.Alumno;

import android.content.Context;

import androidx.lifecycle.LiveData;

import com.example.matricula.Alumnos.ListarAlumnos;
import com.example.matricula.Datas.MatriculaDataBase;

import java.util.List;

public class RepositoryA {

    private final LiveData<List<ListarAlumnos>> ListaAlumnos;
    private final AlumnoDAO alumnoDao;


    public RepositoryA(Context context) {
        MatriculaDataBase mdb = MatriculaDataBase.getInstance(context);
        alumnoDao = mdb.AlumnoDao();
        ListaAlumnos = alumnoDao.getAll();
    }

    public RepositoryA(LiveData<List<ListarAlumnos>> ListaAlumnos, AlumnoDAO alumnoDao) {
        this.ListaAlumnos = ListaAlumnos;
        this.alumnoDao = alumnoDao;
    }


    public LiveData<List<ListarAlumnos>> ListarTodosA() {
        return ListaAlumnos;
    }

    public void insert(Alumno alumno) {
        MatriculaDataBase.mdbExecutor.execute(
                () -> alumnoDao.insert(alumno)
        );
    }

    public void actualizacionAlumno(ListarAlumnos alumnos) {
        MatriculaDataBase.mdbExecutor.execute(
                () -> alumnoDao.update(alumnos)
        );
    }

    public void eliminarAlumno(ListarAlumnos alumnos) {
        MatriculaDataBase.mdbExecutor.execute(
                () -> alumnoDao.delete(alumnos)
        );
    }
}
