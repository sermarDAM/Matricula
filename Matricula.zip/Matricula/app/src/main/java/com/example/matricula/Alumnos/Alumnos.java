package com.example.matricula.Alumnos;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.matricula.Datas.Alumno.Alumno;
import com.example.matricula.R;

public class Alumnos extends AppCompatActivity implements AlumnoDialog.OnSimpleDialogListener {

    private AlumnoViewModel Alumnovm;
    private RecyclerView rvList;
    private AdapterAl Adaptador;
    private String icon_imagen;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.alumnos);

        getSupportActionBar().setTitle("Alumnos");
        ViewModelProvider.AndroidViewModelFactory factory =
                ViewModelProvider.AndroidViewModelFactory.getInstance(getApplication());

        Alumnovm = new ViewModelProvider(this, factory)
                .get(AlumnoViewModel.class);

        setupList();
        setupFab();


    }
    private void setupList() {
        rvList = findViewById(R.id.listaAlumnos);
        Adaptador = new AdapterAl();
        rvList.setAdapter(Adaptador);

        Adaptador.setItemListener(new AdapterAl.ItemListener() {

            @Override
            public void onEditIconClicked(ListarAlumnos Alumno) {

                icon_imagen = "actualizar";
                AlumnoDialog d = new AlumnoDialog(Alumno);
                d.show(getSupportFragmentManager(), "DialogAlumno");

            }

            @Override
            public void onDeleteIconClicked(ListarAlumnos Alumno) {
                Alumnovm.eliminarAlumno(Alumno);
            }

        });
        Alumnovm.ListarTodoA().observe(this, Adaptador::setItems);


    }

    private void setupFab() {

        findViewById(R.id.floatAlumn)
                .setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        icon_imagen = "añadir";
                        dialogoAl();
                    }
                });
    }

    private void dialogoAl() {

        new AlumnoDialog().show(getSupportFragmentManager(), "DialogAlumno");

    }

    @Override
    public void onPossitiveButtonClick(String DNI, String nombre, String apellido) {




        if (icon_imagen.equals("añadir")) {

            Alumno a = new Alumno(DNI, nombre, apellido);
            Alumnovm.insertarAlumno(a);
            Toast.makeText(this, "Se ha añadido con exito " + DNI, Toast.LENGTH_SHORT).show();

        }

        if (icon_imagen.equals("actualizar")) {

            ListarAlumnos a = new ListarAlumnos();
            a.DNI = DNI;
            a.nombre = nombre;
            a.apellido = apellido;
            Alumnovm.actualizacionAlumno(a);
            Toast.makeText(this, "Se ha actualizado correctamente " + DNI, Toast.LENGTH_SHORT).show();

        }
    }
}
