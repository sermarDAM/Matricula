package com.example.matricula;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.matricula.Alumnos.Alumnos;
import com.example.matricula.Asignaturas.Asignaturas;

public class MainActivity extends AppCompatActivity {

    private Button btnAsignaturas, btnAlumnos;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnAsignaturas = (Button) findViewById(R.id.btnAsignaturas);
        btnAlumnos = (Button) findViewById(R.id.btnAlumnos);

        btnAsignaturas.setOnClickListener(new listener_btn());
        btnAlumnos.setOnClickListener(new listener_btn());

    }

    class listener_btn implements View.OnClickListener {
        @Override
        public void onClick(View view) {

            if (view.equals(btnAsignaturas)) {

                Intent intent = new Intent(MainActivity.this, Asignaturas.class);
                startActivity(intent);

            }

            if (view.equals(btnAlumnos)) {

                Intent intent = new Intent(MainActivity.this, Alumnos.class);
                startActivity(intent);

            }
        }
    }
}