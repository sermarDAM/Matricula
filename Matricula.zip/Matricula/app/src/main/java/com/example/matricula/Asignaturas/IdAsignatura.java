package com.example.matricula.Asignaturas;

public class IdAsignatura {

    public int id;

    public IdAsignatura(int id){
        this.id=id;
    }


}
