package com.example.matricula.Datas.Alumno;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Insert;
import androidx.room.Update;

import com.example.matricula.Alumnos.ListarAlumnos;

import java.util.List;

@Dao
public interface AlumnoDAO {

    @Query("SELECT * FROM alumno")
    LiveData<List<ListarAlumnos>> getAll();

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insert(Alumno a);

    @Delete(entity = Alumno.class)
    void delete(ListarAlumnos alumnos);

    @Update(entity = Alumno.class)
    void update(ListarAlumnos alumnos);

}
