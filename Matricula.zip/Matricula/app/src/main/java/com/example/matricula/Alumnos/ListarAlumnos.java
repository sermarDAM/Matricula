package com.example.matricula.Alumnos;

public class ListarAlumnos {

    public String DNI;
    public String nombre;
    public String apellido;

    public String toString(){
        return DNI;
    }

    public String getDNI() {
        return DNI;
    }

    public void setDNI(String DNI) {
        this.DNI = DNI;
    }
}
