package com.example.matricula.Datas.Asignatura;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;


import com.example.matricula.Asignaturas.ListaAsignatura;

import java.util.List;

@Dao
public interface AsignaturaDAO {


    @Query("SELECT * FROM asignatura")
    LiveData<List<ListaAsignatura>> getAll();

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insert(Asignatura as);

    @Delete(entity = Asignatura.class)
    void eliminarAsignatura(ListaAsignatura as);



}
