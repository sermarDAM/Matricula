package com.example.matricula.Alumnos;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

import com.example.matricula.R;

public class AlumnoDialog extends DialogFragment {

    EditText nombreEdit;
    EditText apellidoEdit;
    EditText dniEdit;
    ListarAlumnos alumnos;
    OnSimpleDialogListener listener;

    public AlumnoDialog() {

    }

    public AlumnoDialog(ListarAlumnos alumnos) {
        this.alumnos = alumnos;
    }


    public interface OnSimpleDialogListener {
        void onPossitiveButtonClick(String DNI, String nombre, String apellidos);
    }




    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {

        return createSimpleDialog();
    }

    public AlertDialog createSimpleDialog() {

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        builder.setMessage("Introduzca el nombre del alumno");
        View v = inflater.inflate(R.layout.anadir_alumno, null);
        builder.setView(v);

        nombreEdit = (EditText) v.findViewById(R.id.newNombre);
        apellidoEdit = (EditText) v.findViewById(R.id.newApellido);
        dniEdit = (EditText) v.findViewById(R.id.newDni);


        builder.setPositiveButton("Guardar Alumno", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {

                listener.onPossitiveButtonClick(dniEdit.getText().toString(),
                        nombreEdit.getText().toString(),
                        apellidoEdit.getText().toString());
            }
        })
                .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                        dialog.dismiss();
                    }
                });
        return builder.create();
    }


    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        try {

            listener = (OnSimpleDialogListener) context;

        } catch (ClassCastException e){

        }
    }
}
