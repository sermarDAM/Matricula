package com.example.matricula.Datas.Asignatura;

import android.content.Context;

import androidx.lifecycle.LiveData;

import com.example.matricula.Asignaturas.ListaAsignatura;
import com.example.matricula.Datas.MatriculaDataBase;

import java.util.List;

public class RepositoryAs {

    private final LiveData<List<ListaAsignatura>> ListaAsignaturas;
    private final AsignaturaDAO asignaturaDao;

    public RepositoryAs(Context context) {
        MatriculaDataBase mdb = MatriculaDataBase.getInstance(context);
        asignaturaDao = mdb.AsignaturaDao();
        ListaAsignaturas = asignaturaDao.getAll();
    }

    public RepositoryAs(LiveData<List<ListaAsignatura>> ListaAsignaturas, AsignaturaDAO asignaturaDao) {
        this.ListaAsignaturas = ListaAsignaturas;
        this.asignaturaDao = asignaturaDao;
    }

    public LiveData<List<ListaAsignatura>> ListarTodosAs() {
        return ListaAsignaturas;
    }

    public void insert(Asignatura asignatura) {
        MatriculaDataBase.mdbExecutor.execute(
                () -> asignaturaDao.insert(asignatura)
        );
    }

    public void eliminarAsignatura(ListaAsignatura asignatura) {
        MatriculaDataBase.mdbExecutor.execute(
                () -> asignaturaDao.eliminarAsignatura(asignatura)
        );
    }
}
