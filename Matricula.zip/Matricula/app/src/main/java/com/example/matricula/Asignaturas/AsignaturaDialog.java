package com.example.matricula.Asignaturas;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;
import com.example.matricula.R;

public class AsignaturaDialog extends DialogFragment {

    EditText nomAsig;
    ListaAsignatura asignatura;
    int idAsig;
    int cantAlumnos;
    OnSimpleDialogListener listener;

    public AsignaturaDialog() {

    }


    public interface OnSimpleDialogListener {
        void onPossitiveButtonClick(String nomAsig, int idAsig, int cantAlumnos);

    }




    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        return createSimpleDialog();
    }


    public AlertDialog createSimpleDialog() {

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        builder.setMessage("Introduzca Asignatura");
        View v = inflater.inflate(R.layout.anadir_asignatura, null);
        builder.setView(v);

        nomAsig = (EditText) v.findViewById(R.id.nombreAsig);

        builder.setPositiveButton("Guardar Asignatura", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {

                listener.onPossitiveButtonClick(nomAsig.getText().toString(), idAsig, cantAlumnos);
            }
        })
                .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                        dialog.dismiss();
                    }
                });
        return builder.create();
    }


    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        try {

            listener = (OnSimpleDialogListener) context;

        } catch (ClassCastException e) {


        }
    }
}
