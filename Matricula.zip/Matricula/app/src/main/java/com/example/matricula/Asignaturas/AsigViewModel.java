package com.example.matricula.Asignaturas;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.matricula.Datas.Asignatura.Asignatura;
import com.example.matricula.Datas.Asignatura.RepositoryAs;

import java.util.List;

public class AsigViewModel extends AndroidViewModel {


    private final RepositoryAs reposAsigna;
    private final LiveData<List<ListaAsignatura>> asignaturas;

    public AsigViewModel(@NonNull Application application) {
        super(application);
        reposAsigna = new RepositoryAs(application);
        asignaturas = reposAsigna.ListarTodosAs();
    }


    public LiveData<List<ListaAsignatura>>ListarTodoAsi() {
        return asignaturas;
    }

    public void insert(Asignatura asignatura) {
        reposAsigna.insert(asignatura);
    }

    public void eliminarAsignatura(ListaAsignatura Asignatura) {
        reposAsigna.eliminarAsignatura(Asignatura);
    }
}
