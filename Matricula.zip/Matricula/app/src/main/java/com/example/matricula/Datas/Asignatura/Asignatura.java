package com.example.matricula.Datas.Asignatura;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "asignatura")
public class Asignatura {

    @PrimaryKey(autoGenerate = true)
    private int id;

    @NonNull
    @ColumnInfo(name = "nombre")
    private String nombre;

    @NonNull
    @ColumnInfo(name = "numAlumnos")
    private int numAlumnos;

    public Asignatura(@NonNull String nombre) {

        this.nombre = nombre;
        numAlumnos = 0;
    }

    public int getId() {
        return id;
    }

    @NonNull
    public String getNombre() {
        return nombre;
    }

    public int getNumAlumnos() {
        return numAlumnos;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNumAlumnos(int numAlumnos) {
        this.numAlumnos = numAlumnos;
    }
}
