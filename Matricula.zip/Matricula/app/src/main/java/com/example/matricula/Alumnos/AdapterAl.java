package com.example.matricula.Alumnos;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.matricula.R;

import java.util.List;

public class AdapterAl extends RecyclerView.Adapter<AdapterAl.AlumnoViewHolder> {

    private List<ListarAlumnos> Alumnos;
    private ItemListener itemlisten;



    @NonNull
    @Override
    public AlumnoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new AlumnoViewHolder(
                LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.itemslist_alumno, parent, false)
        );
    }



    public void onBindViewHolder(@NonNull AlumnoViewHolder holder, int position) {
        ListarAlumnos item = Alumnos.get(position);
        holder.bind(item);
    }

    @Override
    public int getItemCount() {
        return Alumnos == null ? 0 : Alumnos.size();
    }

    public void setItems(List<ListarAlumnos> items) {
        Alumnos = items;
        notifyDataSetChanged();
    }

    public void setItemListener(ItemListener listener) {
        itemlisten = listener;
    }


    interface ItemListener {
        void onEditIconClicked(ListarAlumnos Alumno);
        void onDeleteIconClicked(ListarAlumnos Alumno);
    }

    public class AlumnoViewHolder extends RecyclerView.ViewHolder {

        private TextView nombreTxt, apellidosTxt, dniTxt;
        private ImageView infAlumno, actAlumno, eliAlumno;

        public AlumnoViewHolder(@NonNull View itemView) {
            super(itemView);
            nombreTxt = itemView.findViewById(R.id.nombre);
            apellidosTxt = itemView.findViewById(R.id.apellido);
            dniTxt = itemView.findViewById(R.id.DNI);
            infAlumno = itemView.findViewById(R.id.infAlumno);
            actAlumno = itemView.findViewById(R.id.actAlumno);
            eliAlumno = itemView.findViewById(R.id.eliAlumno);


            actAlumno.setOnClickListener(this::manageEvents);
            eliAlumno.setOnClickListener(this::manageEvents);

            itemView.setOnClickListener(this::manageEvents);


        }

        private void manageEvents(View view) {
            if (itemlisten != null) {
                ListarAlumnos clickedItem = Alumnos.get(getAdapterPosition());

                if (view.getId() == R.id.actAlumno) {
                    itemlisten.onEditIconClicked(clickedItem);
                }
                if (view.getId() == R.id.eliAlumno) {
                    itemlisten.onDeleteIconClicked(clickedItem);
                    return;
                }
            }
        }

        public void bind(ListarAlumnos item) {
            nombreTxt.setText(item.nombre);
            apellidosTxt.setText(item.apellido);
            dniTxt.setText(item.DNI);
        }
    }
}
