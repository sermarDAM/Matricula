package com.example.matricula.Alumnos;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;


import com.example.matricula.Datas.Alumno.RepositoryA;
import com.example.matricula.Datas.Alumno.Alumno;

import java.util.List;

public class AlumnoViewModel extends AndroidViewModel {

    private final RepositoryA newRepository;
    private final LiveData<List<ListarAlumnos>> listaAlumnos;

    public AlumnoViewModel(@NonNull Application application) {
        super(application);
        newRepository = new RepositoryA(application);
        listaAlumnos = newRepository.ListarTodosA();
    }

    public LiveData<List<ListarAlumnos>>ListarTodoA(){
        return listaAlumnos;
    }

    public void insertarAlumno(Alumno alumno) {
        newRepository.insert(alumno);
    }

    public void actualizacionAlumno(ListarAlumnos alumnos) {
        newRepository.actualizacionAlumno(alumnos);
    }

    public void eliminarAlumno(ListarAlumnos alumnos) {
        newRepository.eliminarAlumno(alumnos);
    }
}
